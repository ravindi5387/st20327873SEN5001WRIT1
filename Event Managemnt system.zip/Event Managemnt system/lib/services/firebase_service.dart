import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';

class SeedData {
  static final DatabaseReference _db = FirebaseDatabase.instance.ref();
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  static Future<void> seedInitialData() async {
    try {
      // Create admin user if not exists
      try {
        await _auth.createUserWithEmailAndPassword(
          email: 'admin@university.edu',
          password: 'admin123',
        );

        // Get admin UID
        UserCredential adminCredential = await _auth.signInWithEmailAndPassword(
          email: 'admin@university.edu',
          password: 'admin123',
        );

        // Save admin data
        await _db.child('users').child(adminCredential.user!.uid).set({
          'id': adminCredential.user!.uid,
          'name': 'Admin User',
          'email': 'admin@university.edu',
          'role': 'admin',
          'createdAt': DateTime.now().toIso8601String(),
        });
      } catch (e) {
        // Admin might already exist
      }

      // Create student users
      List<Map<String, dynamic>> students = [
        {
          'name': 'John Student',
          'email': 'john@student.edu',
          'password': 'student123',
          'studentId': 'STU001',
          'department': 'Computer Science',
          'year': 3,
        },
        {
          'name': 'Sarah Student',
          'email': 'sarah@student.edu',
          'password': 'student123',
          'studentId': 'STU002',
          'department': 'Engineering',
          'year': 2,
        },
      ];

      for (var studentData in students) {
        try {
          UserCredential studentCredential = await _auth.createUserWithEmailAndPassword(
            email: studentData['email'],
            password: studentData['password'],
          );

          await _db.child('users').child(studentCredential.user!.uid).set({
            'id': studentCredential.user!.uid,
            'name': studentData['name'],
            'email': studentData['email'],
            'role': 'student',
            'studentId': studentData['studentId'],
            'department': studentData['department'],
            'year': studentData['year'],
            'createdAt': DateTime.now().toIso8601String(),
            'registeredEvents': [],
            'notAttendingEvents': [],
          });
        } catch (e) {
          // Student might already exist
        }
      }

      // Create events
      List<Map<String, dynamic>> events = [
        {
          'id': 'event1',
          'title': 'Tech Symposium 2024',
          'description': 'Annual technology symposium featuring guest speakers from top tech companies.',
          'date': DateTime.now().add(const Duration(days: 7)).toIso8601String(),
          'time': '10:00 AM - 4:00 PM',
          'location': 'Engineering Building, Room 101',
          'organizer': 'CS Department',
          'maxAttendees': 100,
          'category': 'Academic',
          'isPublished': true,
          'registeredStudents': [],
          'notAttendingStudents': [],
        },
        {
          'id': 'event2',
          'title': 'Career Fair 2024',
          'description': 'Meet with recruiters from top companies.',
          'date': DateTime.now().add(const Duration(days: 14)).toIso8601String(),
          'time': '9:00 AM - 5:00 PM',
          'location': 'Student Union Building',
          'organizer': 'Career Services',
          'maxAttendees': 200,
          'category': 'Career',
          'isPublished': true,
          'registeredStudents': [],
          'notAttendingStudents': [],
        },
        {
          'id': 'event3',
          'title': 'Welcome Party',
          'description': 'Welcome event for new students.',
          'date': DateTime.now().add(const Duration(days: 3)).toIso8601String(),
          'time': '7:00 PM - 11:00 PM',
          'location': 'Campus Quad',
          'organizer': 'Student Affairs',
          'maxAttendees': 150,
          'category': 'Social',
          'isPublished': true,
          'registeredStudents': [],
          'notAttendingStudents': [],
        },
      ];

      for (var event in events) {
        await _db.child('events').child(event['id']).set(event);
      }

    } catch (e) {
      // Silent fail for seeding
    }
  }
}