import 'dart:convert';
import 'package:http/http.dart' as http;

class MockAPIService {
  // Using JSONPlaceholder which always works
  static const String baseUrl = 'https://jsonplaceholder.typicode.com';

  // Get all posts
  static Future<List<dynamic>> getPosts() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/posts'),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to load posts: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('API Error: $e');
    }
  }

  // Get all users
  static Future<List<dynamic>> getUsers() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/users'),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to load users: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('API Error: $e');
    }
  }

  // Check API connection
  static Future<Map<String, dynamic>> checkConnection() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/posts/1'),
      );

      return {
        'status': response.statusCode,
        'message': response.statusCode == 200 ? 'Connected' : 'Connection issue',
        'url': baseUrl,
        'working': response.statusCode == 200,
      };
    } catch (e) {
      return {
        'status': 500,
        'message': 'Failed to connect: $e',
        'url': baseUrl,
        'working': false,
      };
    }
  }
}