import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';

class SeedData {
  static final DatabaseReference _db = FirebaseDatabase.instance.ref();
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  static Future<void> seedInitialData() async {
    try {
      // Create admin user
      try {
        await _auth.createUserWithEmailAndPassword(
          email: 'admin@university.edu',
          password: 'admin123',
        );
      } catch (e) {
        // Admin might already exist
      }

      // Create sample students
      List<Map<String, dynamic>> students = [
        {
          'id': 'student1',
          'name': 'John Student',
          'email': 'john@student.edu',
          'role': 'student',
          'studentId': 'STU001',
          'department': 'Computer Science',
          'year': 3,
          'registeredEvents': [],
          'notAttendingEvents': [],
        },
        {
          'id': 'student2',
          'name': 'Sarah Student',
          'email': 'sarah@student.edu',
          'role': 'student',
          'studentId': 'STU002',
          'department': 'Engineering',
          'year': 2,
          'registeredEvents': [],
          'notAttendingEvents': [],
        },
      ];

      for (var student in students) {
        await _db.child('users').child(student['id']).set(student);
      }

      // Create sample events
      List<Map<String, dynamic>> events = [
        {
          'id': 'event1',
          'title': 'Tech Symposium 2024',
          'description': 'Annual technology symposium featuring guest speakers from top tech companies.',
          'date': DateTime.now().add(const Duration(days: 7)).toIso8601String(),
          'time': '10:00 AM - 4:00 PM',
          'location': 'Engineering Building, Room 101',
          'organizer': 'CS Department',
          'maxAttendees': 100,
          'category': 'Academic',
          'isPublished': true,
          'registeredStudents': ['student1'],
          'notAttendingStudents': [],
        },
        {
          'id': 'event2',
          'title': 'Career Fair 2024',
          'description': 'Meet with recruiters from top companies.',
          'date': DateTime.now().add(const Duration(days: 14)).toIso8601String(),
          'time': '9:00 AM - 5:00 PM',
          'location': 'Student Union Building',
          'organizer': 'Career Services',
          'maxAttendees': 200,
          'category': 'Career',
          'isPublished': true,
          'registeredStudents': ['student1', 'student2'],
          'notAttendingStudents': [],
        },
      ];

      for (var event in events) {
        await _db.child('events').child(event['id']).set(event);
      }

    } catch (e) {
      // Silent fail
    }
  }
}