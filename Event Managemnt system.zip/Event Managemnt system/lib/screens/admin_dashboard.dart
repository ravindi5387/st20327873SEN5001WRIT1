import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/app_user.dart';
import '../models/event.dart';
import '../models/feedback_model.dart';
import 'admin_api_stats.dart'; // Import the analytics screen

class AdminDashboard extends StatefulWidget {
  final AppUser user;

  const AdminDashboard({super.key, required this.user});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> with SingleTickerProviderStateMixin {
  int _selectedIndex = 0;
  final _eventFormKey = GlobalKey<FormState>();
  bool _isDrawerOpen = false;
  late TabController _tabController;

  // Notification counters
  int _newStudentCount = 0;
  int _newFeedbackCount = 0;
  int _newEventRegistrations = 0;

  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _locationController = TextEditingController();
  final _organizerController = TextEditingController();
  final _maxAttendeesController = TextEditingController();
  final _categoryController = TextEditingController();
  DateTime? _selectedDate;
  String _selectedTime = '10:00 AM';

  // Track previously seen students, feedback, and registrations
  final List<String> _seenStudentIds = [];
  final List<String> _seenFeedbackIds = [];
  final Map<String, List<String>> _seenRegistrations = {};

  int get totalEvents => mockEvents.length;
  int get publishedEvents => mockEvents.where((e) => e.isPublished).length;
  int get totalStudents => mockUsers.where((u) => u.role == 'student').length + registeredUsers.length;
  int get totalFeedback => mockFeedbacks.length;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    _checkNewRegistrations();
    _checkNewFeedback();
    _checkNewEventRegistrations();
  }

  void _checkNewRegistrations() {
    final List<AppUser> allStudents = [...mockUsers.where((u) => u.role == 'student'), ...registeredUsers];
    _newStudentCount = allStudents.where((s) => !_seenStudentIds.contains(s.id)).length;
    for (var student in allStudents) {
      if (!_seenStudentIds.contains(student.id)) {
        _seenStudentIds.add(student.id);
      }
    }
  }

  void _checkNewFeedback() {
    _newFeedbackCount = mockFeedbacks.where((f) => !_seenFeedbackIds.contains(f.id)).length;
    for (var feedback in mockFeedbacks) {
      if (!_seenFeedbackIds.contains(feedback.id)) {
        _seenFeedbackIds.add(feedback.id);
      }
    }
  }

  void _checkNewEventRegistrations() {
    _newEventRegistrations = 0;
    for (var event in mockEvents) {
      if (event.isPublished) {
        final List<String> seenForEvent = _seenRegistrations[event.id] ?? [];
        for (var studentId in event.registeredStudents) {
          if (!seenForEvent.contains(studentId)) {
            _newEventRegistrations++;
          }
        }
      }
    }
  }

  void _markStudentsAsSeen() {
    setState(() {
      _newStudentCount = 0;
    });
  }

  void _markFeedbackAsSeen() {
    setState(() {
      _newFeedbackCount = 0;
    });
  }

  void _markRegistrationsAsSeen() {
    setState(() {
      _newEventRegistrations = 0;
      for (var event in mockEvents) {
        final List<String> seenForEvent = _seenRegistrations[event.id] ?? [];
        for (var studentId in event.registeredStudents) {
          if (!seenForEvent.contains(studentId)) {
            seenForEvent.add(studentId);
          }
        }
        _seenRegistrations[event.id] = seenForEvent;
      }
    });
  }

  // Navigate to System Analytics
  void _navigateToApiStats() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AdminApiStats()),
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _locationController.dispose();
    _organizerController.dispose();
    _maxAttendeesController.dispose();
    _categoryController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;

    return Scaffold(
      appBar: isMobile ? AppBar(
        title: const Text('Admin Dashboard'),
        backgroundColor: Colors.blue.shade800,
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {
            setState(() {
              _isDrawerOpen = !_isDrawerOpen;
            });
            Scaffold.of(context).openDrawer();
          },
        ),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(text: 'Dashboard'),
            Tab(text: 'Events'),
            Tab(text: 'Feedback'),
            Tab(text: 'Students'),
            Tab(text: 'Analytics'),
          ],
        ),
      ) : null,
      drawer: isMobile ? _buildDrawer() : null,
      body: Row(
        children: [
          if (!isMobile)
            Container(
              width: 280,
              decoration: BoxDecoration(
                color: Colors.blue.shade800,
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: Offset(2, 0),
                  ),
                ],
              ),
              child: _buildSideNavigation(),
            ),

          Expanded(
            child: _buildContent(),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: Container(
        color: Colors.blue.shade800,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue.shade900,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: Icon(
                      Icons.admin_panel_settings,
                      size: 30,
                      color: Colors.blue.shade800,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    widget.user.name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Administrator',
                    style: TextStyle(
                      color: Colors.white.withAlpha(200),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            _buildDrawerItem(Icons.dashboard, 'Dashboard', 0, 0),
            _buildDrawerItem(Icons.event, 'Events', 1, _newEventRegistrations),
            _buildDrawerItem(Icons.feedback, 'Feedback', 2, _newFeedbackCount),
            _buildDrawerItem(Icons.people, 'Students', 3, _newStudentCount),
            _buildDrawerItem(Icons.analytics, 'Analytics', 4, 0),
            const Divider(color: Colors.white30),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.white),
              title: const Text('Logout', style: TextStyle(color: Colors.white)),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem(IconData icon, String title, int index, int badgeCount) {
    return ListTile(
      leading: Stack(
        clipBehavior: Clip.none,
        children: [
          Icon(icon, color: Colors.white),
          if (badgeCount > 0)
            Positioned(
              right: -8,
              top: -8,
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: const BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
                constraints: const BoxConstraints(
                  minWidth: 16,
                  minHeight: 16,
                ),
                child: Text(
                  badgeCount.toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
        ],
      ),
      title: Text(title, style: const TextStyle(color: Colors.white)),
      selected: _selectedIndex == index,
      selectedTileColor: Colors.blue.shade700,
      onTap: () {
        setState(() {
          _selectedIndex = index;
          if (index == 2) _markFeedbackAsSeen();
          if (index == 3) _markStudentsAsSeen();
          if (index == 1) _markRegistrationsAsSeen();
          if (index == 4) _navigateToApiStats(); // Navigate to analytics
          _isDrawerOpen = false;
        });
        if (index == 4) {
          Navigator.pop(context); // Close drawer
        }
      },
    );
  }

  Widget _buildSideNavigation() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.blue.shade900,
          ),
          child: Column(
            children: [
              CircleAvatar(
                radius: 40,
                backgroundColor: Colors.white,
                child: Icon(
                  Icons.admin_panel_settings,
                  size: 40,
                  color: Colors.blue.shade800,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                widget.user.name,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Administrator',
                style: TextStyle(
                  color: Colors.white.withAlpha(200),
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),

        Expanded(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              _buildNavItem(Icons.dashboard, 'Dashboard', 0, 0),
              _buildNavItem(Icons.event, 'Events', 1, _newEventRegistrations),
              _buildNavItem(Icons.feedback, 'Feedback', 2, _newFeedbackCount),
              _buildNavItem(Icons.people, 'Students', 3, _newStudentCount),
              _buildNavItem(Icons.analytics, 'Analytics', 4, 0),
            ],
          ),
        ),

        Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.logout),
              label: const Text('Logout'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Colors.blue.shade800,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildNavItem(IconData icon, String title, int index, int badgeCount) {
    return ListTile(
      leading: Stack(
        clipBehavior: Clip.none,
        children: [
          Icon(
            icon,
            color: _selectedIndex == index ? Colors.white : Colors.white.withAlpha(180),
          ),
          if (badgeCount > 0)
            Positioned(
              right: -8,
              top: -8,
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: const BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
                constraints: const BoxConstraints(
                  minWidth: 16,
                  minHeight: 16,
                ),
                child: Text(
                  badgeCount.toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
        ],
      ),
      title: Text(
        title,
        style: TextStyle(
          color: _selectedIndex == index ? Colors.white : Colors.white.withAlpha(180),
          fontWeight: _selectedIndex == index ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      selected: _selectedIndex == index,
      selectedTileColor: Colors.blue.shade700,
      onTap: () {
        setState(() {
          _selectedIndex = index;
          if (index == 2) _markFeedbackAsSeen();
          if (index == 3) _markStudentsAsSeen();
          if (index == 1) _markRegistrationsAsSeen();
        });
        if (index == 4) {
          _navigateToApiStats(); // Navigate to analytics
        }
      },
    );
  }

  Widget _buildContent() {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;

    if (isMobile) {
      return TabBarView(
        controller: _tabController,
        children: [
          _buildDashboardContent(),
          _buildManageEventsContent(),
          _buildFeedbackContent(),
          _buildStudentsContent(),
          _buildAnalyticsPlaceholder(), // Analytics tab placeholder
        ],
      );
    }

    switch (_selectedIndex) {
      case 0:
        return _buildDashboardContent();
      case 1:
        return _buildManageEventsContent();
      case 2:
        return _buildFeedbackContent();
      case 3:
        return _buildStudentsContent();
      case 4:
        return _buildAnalyticsPlaceholder();
      default:
        return Container();
    }
  }

  // Analytics placeholder that opens the full screen
  Widget _buildAnalyticsPlaceholder() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.analytics, size: 80, color: Colors.blue.shade200),
          const SizedBox(height: 16),
          const Text(
            'System Analytics',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            'View detailed API statistics and system metrics',
            style: TextStyle(color: Colors.grey.shade600),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _navigateToApiStats,
            icon: const Icon(Icons.open_in_new),
            label: const Text('Open Analytics Dashboard'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue.shade800,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDashboardContent() {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;
    final allStudents = [...mockUsers.where((u) => u.role == 'student'), ...registeredUsers];

    final List<Map<String, dynamic>> recentRegistrations = [];
    for (var event in mockEvents) {
      for (var studentId in event.registeredStudents) {
        final seenForEvent = _seenRegistrations[event.id] ?? [];
        if (!seenForEvent.contains(studentId)) {
          recentRegistrations.add({'event': event, 'studentId': studentId});
        }
      }
    }

    return Container(
      color: Colors.grey.shade50,
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, 24, isMobile ? 16 : 24, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Admin Dashboard',
                  style: TextStyle(
                    fontSize: isMobile ? 24 : 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Welcome back, ${widget.user.name}',
                  style: TextStyle(
                    fontSize: isMobile ? 14 : 16,
                    color: Colors.grey.shade600,
                  ),
                ),
                const SizedBox(height: 16),
                // Notification summary
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.blue.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.notifications_active, color: Colors.blue.shade800),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'New Updates',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.blue.shade800,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '$_newStudentCount new students, $_newFeedbackCount new feedback, $_newEventRegistrations new registrations',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.blue.shade800,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          Padding(
            padding: EdgeInsets.symmetric(horizontal: isMobile ? 16 : 24),
            child: GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: isMobile ? 2 : 4,
              crossAxisSpacing: isMobile ? 8 : 16,
              mainAxisSpacing: isMobile ? 8 : 16,
              childAspectRatio: isMobile ? 1.5 : 2,
              children: [
                _buildDashboardCard('Total Events', totalEvents.toString(), Icons.event, Colors.blue, isMobile),
                _buildDashboardCard('Published', publishedEvents.toString(), Icons.public, Colors.green, isMobile),
                _buildDashboardCard('Students', totalStudents.toString(), Icons.people, Colors.orange, isMobile),
                _buildDashboardCard('Feedback', totalFeedback.toString(), Icons.feedback, Colors.purple, isMobile),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // System Analytics Button
          Padding(
            padding: EdgeInsets.symmetric(horizontal: isMobile ? 16 : 24),
            child: Container(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _navigateToApiStats,
                icon: const Icon(Icons.analytics),
                label: const Text('📊 View System Analytics'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue.shade300,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Recent Activity
          Expanded(
            child: Padding(
              padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, 8, isMobile ? 16 : 24, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Recent Activity',
                    style: TextStyle(
                      fontSize: isMobile ? 16 : 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: ListView(
                      children: [
                        // Recent Students
                        if (allStudents.isNotEmpty) ...[
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 4),
                            child: Text(
                              'New Students',
                              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                            ),
                          ),
                          ...List.generate(
                            allStudents.length > 3 ? 3 : allStudents.length,
                                (index) {
                              final student = allStudents[allStudents.length - 1 - index];
                              final isNew = !_seenStudentIds.contains(student.id);
                              return Card(
                                margin: const EdgeInsets.only(bottom: 8),
                                color: isNew ? Colors.green.shade50 : Colors.white,
                                child: ListTile(
                                  leading: CircleAvatar(
                                    backgroundColor: Colors.blue.shade100,
                                    child: Text(student.name[0]),
                                  ),
                                  title: Text(student.name),
                                  subtitle: Text(student.email),
                                  trailing: isNew
                                      ? Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: Colors.green,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: const Text(
                                      'NEW',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  )
                                      : null,
                                ),
                              );
                            },
                          ),
                        ],

                        // Recent Event Registrations
                        if (recentRegistrations.isNotEmpty) ...[
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 4),
                            child: Text(
                              'New Event Registrations',
                              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                            ),
                          ),
                          ...recentRegistrations.take(5).map((reg) {
                            final student = allStudents.firstWhere(
                                  (s) => s.id == reg['studentId'],
                              orElse: () => AppUser(id: '', name: 'Unknown', email: '', password: '', role: ''),
                            );
                            final event = reg['event'] as Event;
                            return Card(
                              margin: const EdgeInsets.only(bottom: 8),
                              color: Colors.orange.shade50,
                              child: ListTile(
                                leading: const Icon(Icons.person_add, color: Colors.orange),
                                title: Text('${student.name} registered for ${event.title}'),
                                subtitle: Text(_formatDate(event.date)),
                              ),
                            );
                          }).toList(),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  Widget _buildDashboardCard(String title, String value, IconData icon, Color color, bool isMobile) {
    return Container(
      padding: EdgeInsets.all(isMobile ? 8 : 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(isMobile ? 8 : 12),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: isMobile
          ? Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            title,
            style: TextStyle(
              fontSize: 10,
              color: Colors.grey.shade600,
            ),
            textAlign: TextAlign.center,
            maxLines: 2,
          ),
        ],
      )
          : Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withAlpha(20),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                value,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                title,
                style: TextStyle(
                  fontSize: 11,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildManageEventsContent() {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;

    return Container(
      color: Colors.grey.shade50,
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, 24, isMobile ? 16 : 24, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Manage Events',
                  style: TextStyle(
                    fontSize: isMobile ? 24 : 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Create and manage all events',
                  style: TextStyle(
                    fontSize: isMobile ? 14 : 16,
                    color: Colors.grey.shade600,
                  ),
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () => _showCreateEventDialog(context),
                  icon: const Icon(Icons.add),
                  label: const Text('Create New Event'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue.shade300,
                    foregroundColor: Colors.white,
                    minimumSize: Size(isMobile ? double.infinity : 200, 45),
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: Padding(
              padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, 8, isMobile ? 16 : 24, 24),
              child: ListView.builder(
                itemCount: mockEvents.length,
                itemBuilder: (context, index) {
                  final event = mockEvents[index];
                  final newRegistrations = event.registeredStudents
                      .where((sid) => !(_seenRegistrations[event.id]?.contains(sid) ?? true))
                      .length;

                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ExpansionTile(
                      leading: Stack(
                        children: [
                          CircleAvatar(
                            backgroundColor: event.isPublished ? Colors.green : Colors.orange,
                            child: Icon(
                              event.isPublished ? Icons.public : Icons.lock,
                              color: Colors.white,
                              size: 16,
                            ),
                          ),
                          if (newRegistrations > 0)
                            Positioned(
                              right: -4,
                              top: -4,
                              child: Container(
                                padding: const EdgeInsets.all(4),
                                decoration: const BoxDecoration(
                                  color: Colors.red,
                                  shape: BoxShape.circle,
                                ),
                                constraints: const BoxConstraints(
                                  minWidth: 16,
                                  minHeight: 16,
                                ),
                                child: Text(
                                  newRegistrations.toString(),
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 8,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                      title: Text(
                        event.title,
                        style: TextStyle(fontSize: isMobile ? 14 : 16, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${event.registeredCount} registered, ${event.notAttendingCount} not attending',
                            style: TextStyle(fontSize: isMobile ? 12 : 14),
                          ),
                          if (newRegistrations > 0)
                            Text(
                              '$newRegistrations new registrations',
                              style: const TextStyle(
                                color: Colors.red,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                        ],
                      ),
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildDetailRow(Icons.description, 'Description: ${event.description}', isMobile),
                              const SizedBox(height: 8),
                              _buildDetailRow(Icons.location_on, 'Location: ${event.location}', isMobile),
                              const SizedBox(height: 8),
                              _buildDetailRow(Icons.access_time, 'Date: ${_formatDate(event.date)} at ${event.time}', isMobile),
                              const SizedBox(height: 8),
                              _buildDetailRow(Icons.person, 'Organizer: ${event.organizer}', isMobile),
                              const SizedBox(height: 8),
                              _buildDetailRow(Icons.category, 'Category: ${event.category}', isMobile),
                              const SizedBox(height: 16),

                              // Show registered students
                              if (event.registeredStudents.isNotEmpty) ...[
                                const Text(
                                  'Registered Students:',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(height: 8),
                                ...event.registeredStudents.map((sid) {
                                  final student = [...mockUsers, ...registeredUsers]
                                      .firstWhere((u) => u.id == sid, orElse: () => AppUser(id: '', name: 'Unknown', email: '', password: '', role: ''));
                                  final isNew = !(_seenRegistrations[event.id]?.contains(sid) ?? true);
                                  return Container(
                                    margin: const EdgeInsets.only(bottom: 4),
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: isNew ? Colors.green.shade50 : Colors.grey.shade50,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Row(
                                      children: [
                                        CircleAvatar(
                                          radius: 12,
                                          backgroundColor: Colors.blue.shade100,
                                          child: Text(
                                            student.name.isNotEmpty ? student.name[0] : '?',
                                            style: const TextStyle(fontSize: 10),
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                student.name,
                                                style: const TextStyle(fontWeight: FontWeight.w500),
                                              ),
                                              Text(
                                                student.studentId ?? '',
                                                style: TextStyle(
                                                  fontSize: 10,
                                                  color: Colors.grey.shade600,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        if (isNew)
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: Colors.green,
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            child: const Text(
                                              'NEW',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 8,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                                const SizedBox(height: 16),
                              ],

                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  ElevatedButton.icon(
                                    onPressed: () {
                                      setState(() {
                                        event.isPublished = !event.isPublished;
                                      });
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                          content: Text(
                                              event.isPublished
                                                  ? 'Event published!'
                                                  : 'Event unpublished'
                                          ),
                                          backgroundColor: event.isPublished ? Colors.green : Colors.orange,
                                        ),
                                      );
                                    },
                                    icon: Icon(event.isPublished ? Icons.public_off : Icons.public),
                                    label: Text(event.isPublished ? 'Unpublish' : 'Publish'),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: event.isPublished ? Colors.orange : Colors.green,
                                      foregroundColor: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String text, bool isMobile) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: isMobile ? 16 : 18, color: Colors.grey.shade600),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: TextStyle(fontSize: isMobile ? 13 : 14),
          ),
        ),
      ],
    );
  }

  void _showCreateEventDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Create New Event'),
          content: SingleChildScrollView(
            child: Container(
              width: MediaQuery.of(context).size.width * (MediaQuery.of(context).size.width < 600 ? 0.9 : 0.5),
              padding: const EdgeInsets.all(8),
              child: Form(
                key: _eventFormKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextFormField(
                      controller: _titleController,
                      decoration: const InputDecoration(
                        labelText: 'Event Title *',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.title),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter event title';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _descriptionController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Description *',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.description),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter description';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _locationController,
                      decoration: const InputDecoration(
                        labelText: 'Location *',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.location_on),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter location';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _organizerController,
                      decoration: const InputDecoration(
                        labelText: 'Organizer *',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.person),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter organizer';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _maxAttendeesController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Max Attendees *',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.people),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter max attendees';
                        }
                        if (int.tryParse(value) == null) {
                          return 'Please enter a valid number';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _categoryController,
                      decoration: const InputDecoration(
                        labelText: 'Category *',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.category),
                        hintText: 'Academic, Career, Social, etc.',
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter category';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () => _selectDate(context),
                            child: InputDecorator(
                              decoration: const InputDecoration(
                                labelText: 'Date *',
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.calendar_today),
                              ),
                              child: Text(
                                _selectedDate == null
                                    ? 'Select Date'
                                    : _formatDate(_selectedDate!),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: _selectedTime,
                            decoration: const InputDecoration(
                              labelText: 'Time',
                              border: OutlineInputBorder(),
                              prefixIcon: Icon(Icons.access_time),
                            ),
                            items: const [
                              DropdownMenuItem(value: '9:00 AM', child: Text('9:00 AM')),
                              DropdownMenuItem(value: '10:00 AM', child: Text('10:00 AM')),
                              DropdownMenuItem(value: '11:00 AM', child: Text('11:00 AM')),
                              DropdownMenuItem(value: '12:00 PM', child: Text('12:00 PM')),
                              DropdownMenuItem(value: '1:00 PM', child: Text('1:00 PM')),
                              DropdownMenuItem(value: '2:00 PM', child: Text('2:00 PM')),
                              DropdownMenuItem(value: '3:00 PM', child: Text('3:00 PM')),
                              DropdownMenuItem(value: '4:00 PM', child: Text('4:00 PM')),
                              DropdownMenuItem(value: '5:00 PM', child: Text('5:00 PM')),
                            ],
                            onChanged: (String? newValue) {
                              setState(() {
                                _selectedTime = newValue!;
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                _resetForm();
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (_eventFormKey.currentState!.validate() && _selectedDate != null) {
                  _createEvent();
                  Navigator.pop(context);
                } else if (_selectedDate == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Please select a date'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue.shade300,
                foregroundColor: Colors.white,
              ),
              child: const Text('Create'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _createEvent() {
    if (_selectedDate == null) return;

    final newEvent = Event(
      id: (mockEvents.length + 1).toString(),
      title: _titleController.text,
      description: _descriptionController.text,
      date: _selectedDate!,
      time: _selectedTime,
      location: _locationController.text,
      organizer: _organizerController.text,
      maxAttendees: int.parse(_maxAttendeesController.text),
      category: _categoryController.text,
      isPublished: false,
    );

    setState(() {
      mockEvents.add(newEvent);
      _resetForm();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Event created successfully!'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _resetForm() {
    _titleController.clear();
    _descriptionController.clear();
    _locationController.clear();
    _organizerController.clear();
    _maxAttendeesController.clear();
    _categoryController.clear();
    setState(() {
      _selectedDate = null;
      _selectedTime = '10:00 AM';
    });
  }

  Widget _buildFeedbackContent() {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;
    final allStudents = [...mockUsers.where((u) => u.role == 'student'), ...registeredUsers];

    return Container(
      color: Colors.grey.shade50,
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, 24, isMobile ? 16 : 24, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Student Feedback',
                  style: TextStyle(
                    fontSize: isMobile ? 24 : 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'View all feedback and ratings from students',
                  style: TextStyle(
                    fontSize: isMobile ? 14 : 16,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: Padding(
              padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, 8, isMobile ? 16 : 24, 24),
              child: ListView.builder(
                itemCount: mockFeedbacks.length,
                itemBuilder: (context, index) {
                  final feedback = mockFeedbacks[index];
                  final event = mockEvents.firstWhere(
                        (e) => e.id == feedback.eventId,
                  );
                  final student = allStudents.firstWhere(
                        (u) => u.id == feedback.studentId,
                    orElse: () => AppUser(id: '', name: 'Unknown', email: '', password: '', role: ''),
                  );
                  final isNew = !_seenFeedbackIds.contains(feedback.id);

                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    elevation: 2,
                    color: isNew ? Colors.green.shade50 : Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(isMobile ? 12 : 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                radius: isMobile ? 16 : 20,
                                backgroundColor: Colors.blue.shade100,
                                child: Text(
                                  student.name.isNotEmpty ? student.name[0] : '?',
                                  style: TextStyle(
                                    color: Colors.blue.shade800,
                                    fontWeight: FontWeight.bold,
                                    fontSize: isMobile ? 12 : 14,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          student.name,
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: isMobile ? 14 : 16,
                                          ),
                                        ),
                                        if (isNew) ...[
                                          const SizedBox(width: 8),
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: Colors.green,
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            child: const Text(
                                              'NEW',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 8,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ],
                                    ),
                                    Text(
                                      event.title,
                                      style: TextStyle(
                                        fontSize: isMobile ? 12 : 14,
                                        color: Colors.grey.shade600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.amber.withAlpha(20),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.star, color: Colors.amber, size: isMobile ? 14 : 16),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${feedback.starRating}/5',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: isMobile ? 12 : 14,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            feedback.comment,
                            style: TextStyle(
                              fontSize: isMobile ? 13 : 14,
                              color: Colors.grey.shade800,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _formatDate(feedback.timestamp),
                            style: TextStyle(
                              fontSize: isMobile ? 11 : 12,
                              color: Colors.grey.shade500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStudentsContent() {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;
    final allStudents = [...mockUsers.where((u) => u.role == 'student'), ...registeredUsers];

    return Container(
      color: Colors.grey.shade50,
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, 24, isMobile ? 16 : 24, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Students',
                  style: TextStyle(
                    fontSize: isMobile ? 24 : 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'View all registered students',
                  style: TextStyle(
                    fontSize: isMobile ? 14 : 16,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: Padding(
              padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, 8, isMobile ? 16 : 24, 24),
              child: ListView.builder(
                itemCount: allStudents.length,
                itemBuilder: (context, index) {
                  final student = allStudents[index];
                  final studentEvents = mockEvents
                      .where((e) => e.registeredStudents.contains(student.id))
                      .length;
                  final studentNotAttending = mockEvents
                      .where((e) => e.notAttendingStudents.contains(student.id))
                      .length;
                  final isNew = !_seenStudentIds.contains(student.id);

                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    elevation: 2,
                    color: isNew ? Colors.green.shade50 : Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: EdgeInsets.all(isMobile ? 12 : 16),
                      leading: CircleAvatar(
                        backgroundColor: Colors.blue.shade100,
                        radius: isMobile ? 20 : 24,
                        child: Text(
                          student.name[0],
                          style: TextStyle(
                            color: Colors.blue.shade800,
                            fontWeight: FontWeight.bold,
                            fontSize: isMobile ? 14 : 16,
                          ),
                        ),
                      ),
                      title: Row(
                        children: [
                          Expanded(
                            child: Text(
                              student.name,
                              style: TextStyle(
                                fontSize: isMobile ? 14 : 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          if (isNew)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.green,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Text(
                                'NEW',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                        ],
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${student.studentId} • ${student.department} • Year ${student.year}',
                            style: TextStyle(fontSize: isMobile ? 12 : 14),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.green.shade50,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  '$studentEvents attending',
                                  style: TextStyle(
                                    fontSize: isMobile ? 10 : 11,
                                    color: Colors.green.shade700,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.red.shade50,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  '$studentNotAttending not attending',
                                  style: TextStyle(
                                    fontSize: isMobile ? 10 : 11,
                                    color: Colors.red.shade700,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}