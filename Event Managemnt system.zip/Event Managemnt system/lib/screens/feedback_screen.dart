import 'package:flutter/material.dart';
import '../models/app_user.dart';
import '../models/event.dart';
import '../models/feedback_model.dart';

class FeedbackScreen extends StatefulWidget {
  final AppUser user;
  final VoidCallback? onFeedbackSubmitted;

  const FeedbackScreen({super.key, required this.user, this.onFeedbackSubmitted});

  @override
  State<FeedbackScreen> createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  final _commentController = TextEditingController();
  int _selectedRating = 0;
  Event? _selectedEvent;

  List<Event> get _registeredEvents {
    return mockEvents
        .where((e) => e.registeredStudents.contains(widget.user.id))
        .toList();
  }

  List<FeedbackModel> get _myFeedbacks {
    return mockFeedbacks
        .where((f) => f.studentId == widget.user.id)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Event Feedback',
            style: TextStyle(
              fontSize: isMobile ? 24 : 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Share your experience and rate events',
            style: TextStyle(
              fontSize: isMobile ? 14 : 16,
              color: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 16),

          if (_registeredEvents.isNotEmpty) ...[
            Card(
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Submit New Feedback',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),

                    DropdownButtonFormField<Event>(
                      value: _selectedEvent,
                      decoration: const InputDecoration(
                        labelText: 'Select Event',
                        border: OutlineInputBorder(),
                      ),
                      items: _registeredEvents.map((event) {
                        return DropdownMenuItem(
                          value: event,
                          child: Text(event.title),
                        );
                      }).toList(),
                      onChanged: (Event? newValue) {
                        setState(() {
                          _selectedEvent = newValue;
                        });
                      },
                    ),
                    const SizedBox(height: 16),

                    const Text('Your Rating:'),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(5, (index) {
                        return IconButton(
                          onPressed: () {
                            setState(() {
                              _selectedRating = index + 1;
                            });
                          },
                          icon: Icon(
                            index < _selectedRating ? Icons.star : Icons.star_border,
                            color: Colors.amber,
                            size: 32,
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 16),

                    TextFormField(
                      controller: _commentController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Your Comment',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _selectedEvent != null && _selectedRating > 0
                            ? _submitFeedback
                            : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue.shade300, // Lighter color
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: const Text('Submit Feedback'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],

          const Text(
            'My Feedback History',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),

          Expanded(
            child: _myFeedbacks.isEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.feedback_outlined,
                    size: 48,
                    color: Colors.grey.shade400,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'No feedback yet',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            )
                : ListView.builder(
              itemCount: _myFeedbacks.length,
              itemBuilder: (context, index) {
                final feedback = _myFeedbacks[index];
                final event = mockEvents.firstWhere(
                      (e) => e.id == feedback.eventId,
                );

                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  elevation: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          event.title,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: List.generate(5, (starIndex) {
                            return Icon(
                              starIndex < feedback.starRating ? Icons.star : Icons.star_border,
                              color: Colors.amber,
                              size: 16,
                            );
                          }),
                        ),
                        const SizedBox(height: 4),
                        Text(feedback.comment),
                        const SizedBox(height: 4),
                        Text(
                          '${feedback.timestamp.day}/${feedback.timestamp.month}/${feedback.timestamp.year}',
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.grey.shade500,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _submitFeedback() {
    final newFeedback = FeedbackModel(
      id: (mockFeedbacks.length + 1).toString(),
      eventId: _selectedEvent!.id,
      studentId: widget.user.id,
      studentName: widget.user.name,
      comment: _commentController.text,
      timestamp: DateTime.now(),
      starRating: _selectedRating,
    );

    setState(() {
      mockFeedbacks.add(newFeedback);
      _selectedEvent = null;
      _selectedRating = 0;
      _commentController.clear();
    });

    // Notify parent that feedback was submitted (to update admin notification)
    if (widget.onFeedbackSubmitted != null) {
      widget.onFeedbackSubmitted!();
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Feedback submitted!'),
        backgroundColor: Colors.green,
      ),
    );
  }
}