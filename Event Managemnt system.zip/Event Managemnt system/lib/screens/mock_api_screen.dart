import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MockApiScreen extends StatefulWidget {
  const MockApiScreen({super.key});

  @override
  State<MockApiScreen> createState() => _MockApiScreenState();
}

class _MockApiScreenState extends State<MockApiScreen> {
  List<dynamic> _posts = [];
  List<dynamic> _users = [];
  bool _isLoading = false;
  String _errorMessage = '';
  String _selectedTab = 'posts';

  // Fetch posts from JSONPlaceholder API
  Future<void> _fetchPosts() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final response = await http.get(
        Uri.parse('https://jsonplaceholder.typicode.com/posts'),
      );

      if (response.statusCode == 200) {
        setState(() {
          _posts = json.decode(response.body);
          _isLoading = false;
        });
      } else {
        setState(() {
          _errorMessage = 'Failed to load posts: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error: $e';
        _isLoading = false;
      });
    }
  }

  // Fetch users from JSONPlaceholder API
  Future<void> _fetchUsers() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final response = await http.get(
        Uri.parse('https://jsonplaceholder.typicode.com/users'),
      );

      if (response.statusCode == 200) {
        setState(() {
          _users = json.decode(response.body);
          _isLoading = false;
        });
      } else {
        setState(() {
          _errorMessage = 'Failed to load users: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error: $e';
        _isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchPosts(); // Load posts by default
  }

  void _switchTab(String tab) {
    setState(() {
      _selectedTab = tab;
    });
    if (tab == 'posts') {
      _fetchPosts();
    } else {
      _fetchUsers();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('📡 Mock API Demo'),
        backgroundColor: Colors.purple.shade800,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // API Info Banner
          Container(
            padding: const EdgeInsets.all(12),
            color: Colors.purple.shade50,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.info, color: Colors.purple.shade800),
                    const SizedBox(width: 8),
                    const Text(
                      'JSONPlaceholder API - Free fake API for testing',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                SelectableText(
                  'https://jsonplaceholder.typicode.com/${_selectedTab == 'posts' ? 'posts' : 'users'}',
                  style: TextStyle(fontSize: 11, color: Colors.purple.shade700),
                ),
              ],
            ),
          ),

          // Tab Selector
          Container(
            color: Colors.purple.shade800,
            child: Row(
              children: [
                Expanded(
                  child: _buildTabButton('Posts', 'posts'),
                ),
                Expanded(
                  child: _buildTabButton('Users', 'users'),
                ),
              ],
            ),
          ),

          // Content
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _errorMessage.isNotEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error_outline, size: 48, color: Colors.red),
                  const SizedBox(height: 16),
                  Text(_errorMessage),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _selectedTab == 'posts' ? _fetchPosts : _fetchUsers,
                    child: const Text('Try Again'),
                  ),
                ],
              ),
            )
                : _selectedTab == 'posts'
                ? _buildPostsList()
                : _buildUsersList(),
          ),

          // Footer
          Container(
            padding: const EdgeInsets.all(8),
            color: Colors.grey.shade100,
            child: const Center(
              child: Text(
                'Data from JSONPlaceholder API',
                style: TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(String label, String tab) {
    final isSelected = _selectedTab == tab;
    return InkWell(
      onTap: () => _switchTab(tab),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: isSelected ? Colors.white : Colors.transparent,
              width: 3,
            ),
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.white.withAlpha(180),
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPostsList() {
    if (_posts.isEmpty) {
      return const Center(child: Text('No posts data'));
    }

    return ListView.builder(
      padding: const EdgeInsets.all(8),
      itemCount: _posts.length > 10 ? 10 : _posts.length, // Show only first 10
      itemBuilder: (context, index) {
        final post = _posts[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.purple.shade100,
              child: Text('${post['id']}', style: TextStyle(color: Colors.purple.shade800)),
            ),
            title: Text(post['title'], maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(post['body'], maxLines: 2, overflow: TextOverflow.ellipsis),
            isThreeLine: true,
          ),
        );
      },
    );
  }

  Widget _buildUsersList() {
    if (_users.isEmpty) {
      return const Center(child: Text('No users data'));
    }

    return ListView.builder(
      padding: const EdgeInsets.all(8),
      itemCount: _users.length,
      itemBuilder: (context, index) {
        final user = _users[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.purple.shade100,
              child: Text(
                user['name'][0],
                style: TextStyle(color: Colors.purple.shade800, fontWeight: FontWeight.bold),
              ),
            ),
            title: Text(user['name']),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user['email']),
                Text('${user['company']['name']}'),
              ],
            ),
          ),
        );
      },
    );
  }
}