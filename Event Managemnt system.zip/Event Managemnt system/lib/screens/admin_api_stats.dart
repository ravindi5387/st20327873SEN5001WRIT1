import 'package:flutter/material.dart';
import '../services/mockapi_service.dart';
import '../models/event.dart';
import '../models/app_user.dart';

class AdminApiStats extends StatefulWidget {
  const AdminApiStats({super.key});

  @override
  State<AdminApiStats> createState() => _AdminApiStatsState();
}

class _AdminApiStatsState extends State<AdminApiStats> with SingleTickerProviderStateMixin {
  List<dynamic> _posts = [];
  List<dynamic> _users = [];
  bool _isLoading = false;
  String? _errorMessage;
  late TabController _tabController;

  // Event category data
  final Map<String, int> _eventCategories = {};
  final Map<String, Color> _categoryColors = {};
  int _totalEvents = 0;
  int _totalStudents = 0;
  int _totalRegistrations = 0;
  String _mostPopularCategory = '';
  String _mostPopularEvent = '';

  // Colors for pie chart slices
  final List<Color> _pieColors = [
    Colors.blue,
    Colors.green,
    Colors.orange,
    Colors.purple,
    Colors.red,
    Colors.teal,
    Colors.pink,
    Colors.amber,
    Colors.indigo,
    Colors.cyan,
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _fetchData();
    _calculateEventStats();
  }

  void _calculateEventStats() {
    _eventCategories.clear();
    _totalEvents = mockEvents.length;
    _totalStudents = mockUsers.where((u) => u.role == 'student').length + registeredUsers.length;
    _totalRegistrations = 0;

    Map<String, int> categoryRegistrations = {};

    int colorIndex = 0;
    for (var event in mockEvents) {
      // Count events by category
      _eventCategories[event.category] = (_eventCategories[event.category] ?? 0) + 1;

      // Assign color to category if not already assigned
      if (!_categoryColors.containsKey(event.category)) {
        _categoryColors[event.category] = _pieColors[colorIndex % _pieColors.length];
        colorIndex++;
      }

      // Count registrations by category
      categoryRegistrations[event.category] = (categoryRegistrations[event.category] ?? 0) + event.registeredCount;
      _totalRegistrations += event.registeredCount;
    }

    // Find most popular category (by registrations)
    int maxRegistrations = 0;
    categoryRegistrations.forEach((category, count) {
      if (count > maxRegistrations) {
        maxRegistrations = count;
        _mostPopularCategory = category;
      }
    });

    // Find most popular event
    int maxEventRegistrations = 0;
    for (var event in mockEvents) {
      if (event.registeredCount > maxEventRegistrations) {
        maxEventRegistrations = event.registeredCount;
        _mostPopularEvent = event.title;
      }
    }
  }

  Future<void> _fetchData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final posts = await MockAPIService.getPosts();
      final users = await MockAPIService.getUsers();

      setState(() {
        _posts = posts;
        _users = users;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('📊 Analytics Dashboard'),
        backgroundColor: Colors.blue.shade800,
        foregroundColor: Colors.white,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.pie_chart), text: 'Charts'),
            Tab(icon: Icon(Icons.bar_chart), text: 'Statistics'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchData,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 48, color: Colors.red),
            const SizedBox(height: 16),
            Text('Error: $_errorMessage'),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _fetchData,
              child: const Text('Retry'),
            ),
          ],
        ),
      )
          : TabBarView(
        controller: _tabController,
        children: [
          // Charts Tab
          _buildChartsTab(),
          // Statistics Tab
          _buildStatisticsTab(),
        ],
      ),
    );
  }

  Widget _buildChartsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // API Status Card
          _buildApiStatusCard(),

          const SizedBox(height: 20),

          // Event Distribution Pie Chart
          _buildPieChartCard(),

          const SizedBox(height: 20),

          // Student Participation Chart
          _buildStudentPieChart(),

          const SizedBox(height: 20),

          // Legend
          _buildLegendCard(),

          const SizedBox(height: 20),

          // API Footer
          _buildApiFooter(),
        ],
      ),
    );
  }

  Widget _buildStatisticsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildApiStatusCard(),
          const SizedBox(height: 20),
          _buildEventAnalytics(),
          const SizedBox(height: 20),
          _buildStudentAnalytics(),
          const SizedBox(height: 20),
          _buildCategoryDistribution(),
          const SizedBox(height: 20),
          _buildApiFooter(),
        ],
      ),
    );
  }

  Widget _buildApiStatusCard() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.blue.shade50, Colors.purple.shade50],
          ),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade800,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.api, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 12),
                const Text(
                  'External API Status',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatusCircle('Posts', _posts.length.toString(), Colors.blue, Icons.post_add),
                _buildStatusCircle('Users', _users.length.toString(), Colors.green, Icons.people),
                _buildStatusCircle('Success', '100%', Colors.purple, Icons.check_circle),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusCircle(String label, String value, Color color, IconData icon) {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: color.withAlpha(20),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color, size: 30),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade600,
          ),
        ),
      ],
    );
  }

  Widget _buildPieChartCard() {
    if (_eventCategories.isEmpty) {
      return const SizedBox();
    }

    final total = _eventCategories.values.reduce((a, b) => a + b);

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.purple.shade800,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.pie_chart, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 12),
                const Text(
                  'Event Categories Distribution',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Custom Pie Chart
            Center(
              child: Container(
                width: 200,
                height: 200,
                child: CustomPaint(
                  painter: PieChartPainter(
                    categories: _eventCategories,
                    colors: _categoryColors,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Category List with Colors
            ..._eventCategories.entries.map((entry) {
              final percentage = (entry.value / total) * 100;
              final color = _categoryColors[entry.key] ?? Colors.grey;

              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    Container(
                      width: 16,
                      height: 16,
                      decoration: BoxDecoration(
                        color: color,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 2,
                      child: Text(
                        entry.key,
                        style: const TextStyle(fontWeight: FontWeight.w500),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Text(
                        '${entry.value} events',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ),
                    Text(
                      '${percentage.toStringAsFixed(1)}%',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: color,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),

            const SizedBox(height: 16),

            // Total
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Total Events:',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    total.toString(),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.purple,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStudentPieChart() {
    final activeStudents = mockUsers.where((u) =>
    u.role == 'student' && mockEvents.any((e) => e.registeredStudents.contains(u.id))
    ).length + registeredUsers.where((u) =>
        mockEvents.any((e) => e.registeredStudents.contains(u.id))
    ).length;

    final inactiveStudents = _totalStudents - activeStudents;

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.green.shade800,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.people, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 12),
                const Text(
                  'Student Participation',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Student Pie Chart
            Center(
              child: Container(
                width: 150,
                height: 150,
                child: CustomPaint(
                  painter: StudentPieChartPainter(
                    active: activeStudents,
                    inactive: inactiveStudents,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Legend
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildLegendItem('Active', activeStudents, Colors.green),
                _buildLegendItem('Inactive', inactiveStudents, Colors.red),
              ],
            ),

            const SizedBox(height: 16),

            // Stats
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Column(
                    children: [
                      Text(
                        activeStudents.toString(),
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                      const Text('Active'),
                    ],
                  ),
                  Container(
                    height: 40,
                    width: 1,
                    color: Colors.grey.shade300,
                  ),
                  Column(
                    children: [
                      Text(
                        inactiveStudents.toString(),
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.red,
                        ),
                      ),
                      const Text('Inactive'),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLegendItem(String label, int count, Color color) {
    return Row(
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 4),
        Text(
          '$label ($count)',
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade700,
          ),
        ),
      ],
    );
  }

  Widget _buildLegendCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Color Legend',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 16,
              runSpacing: 8,
              children: _categoryColors.entries.map((entry) {
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: entry.value,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(entry.key),
                  ],
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEventAnalytics() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.orange.shade800,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.event, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 12),
                const Text(
                  'Event Analytics',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Stats Grid
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              childAspectRatio: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              children: [
                _buildAnalyticsCard(
                  'Total Events',
                  _totalEvents.toString(),
                  Icons.event,
                  Colors.blue,
                ),
                _buildAnalyticsCard(
                  'Total Registrations',
                  _totalRegistrations.toString(),
                  Icons.people,
                  Colors.green,
                ),
                _buildAnalyticsCard(
                  'Categories',
                  _eventCategories.length.toString(),
                  Icons.category,
                  Colors.orange,
                ),
                _buildAnalyticsCard(
                  'Avg per Event',
                  (_totalRegistrations / (_totalEvents > 0 ? _totalEvents : 1)).toStringAsFixed(1),
                  Icons.calculate,
                  Colors.purple,
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Most Popular Section
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.amber.shade50,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const Icon(Icons.emoji_events, color: Colors.amber, size: 32),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Most Popular Category',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                        Text(
                          _mostPopularCategory.isNotEmpty ? _mostPopularCategory : 'N/A',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'Most Popular Event',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                        Text(
                          _mostPopularEvent.isNotEmpty ? _mostPopularEvent : 'N/A',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStudentAnalytics() {
    final activeStudents = mockUsers.where((u) =>
    u.role == 'student' && mockEvents.any((e) => e.registeredStudents.contains(u.id))
    ).length + registeredUsers.where((u) =>
        mockEvents.any((e) => e.registeredStudents.contains(u.id))
    ).length;

    final inactiveStudents = _totalStudents - activeStudents;

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.green.shade800,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.people, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 12),
                const Text(
                  'Student Analytics',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Student Stats
            Row(
              children: [
                Expanded(
                  child: _buildProgressCard(
                    'Total Students',
                    _totalStudents.toString(),
                    Icons.people_outline,
                    Colors.blue,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildProgressCard(
                    'Active',
                    activeStudents.toString(),
                    Icons.person,
                    Colors.green,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildProgressCard(
                    'Inactive',
                    inactiveStudents.toString(),
                    Icons.person_off,
                    Colors.red,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Active vs Inactive Progress Bar
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Student Participation',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: LinearProgressIndicator(
                    value: _totalStudents > 0 ? activeStudents / _totalStudents : 0,
                    backgroundColor: Colors.grey.shade200,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.green.shade400),
                    minHeight: 20,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '${((activeStudents / (_totalStudents > 0 ? _totalStudents : 1)) * 100).toStringAsFixed(1)}% Active',
                      style: TextStyle(fontSize: 12, color: Colors.green.shade700),
                    ),
                    Text(
                      '${((inactiveStudents / (_totalStudents > 0 ? _totalStudents : 1)) * 100).toStringAsFixed(1)}% Inactive',
                      style: TextStyle(fontSize: 12, color: Colors.red.shade700),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryDistribution() {
    if (_eventCategories.isEmpty) {
      return const SizedBox();
    }

    final total = _eventCategories.values.reduce((a, b) => a + b);

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.purple.shade800,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.pie_chart, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 12),
                const Text(
                  'Event Categories Distribution',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Category List with Progress Bars
            ..._eventCategories.entries.map((entry) {
              final percentage = (entry.value / total) * 100;
              final color = _categoryColors[entry.key] ?? Colors.grey;

              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  children: [
                    Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        color: color,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      flex: 2,
                      child: Text(
                        entry.key,
                        style: const TextStyle(fontWeight: FontWeight.w500),
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: LinearProgressIndicator(
                          value: entry.value / total,
                          backgroundColor: Colors.grey.shade200,
                          valueColor: AlwaysStoppedAnimation<Color>(color),
                          minHeight: 15,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      '${entry.value} (${percentage.toStringAsFixed(1)}%)',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: color,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),

            const SizedBox(height: 16),

            // Summary
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Total Categories:',
                    style: TextStyle(fontWeight: FontWeight.w500),
                  ),
                  Text(
                    _eventCategories.length.toString(),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.purple,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnalyticsCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withAlpha(10),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withAlpha(30)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            title,
            style: TextStyle(
              fontSize: 10,
              color: Colors.grey.shade600,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildProgressCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: color.withAlpha(10),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            title,
            style: TextStyle(
              fontSize: 9,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildApiFooter() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.info, size: 16, color: Colors.blue.shade800),
          const SizedBox(width: 8),
          Text(
            'Data from JSONPlaceholder API | ${_posts.length} Posts • ${_users.length} Users',
            style: TextStyle(
              color: Colors.blue.shade800,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// Custom Painter for Event Categories Pie Chart
class PieChartPainter extends CustomPainter {
  final Map<String, int> categories;
  final Map<String, Color> colors;

  PieChartPainter({required this.categories, required this.colors});

  @override
  void paint(Canvas canvas, Size size) {
    if (categories.isEmpty) return;

    final total = categories.values.reduce((a, b) => a + b);
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    double startAngle = -90 * (3.14159 / 180); // Start from top

    final entries = categories.entries.toList();

    for (var entry in entries) {
      final sweepAngle = (entry.value / total) * 360 * (3.14159 / 180);

      final paint = Paint()
        ..color = colors[entry.key] ?? Colors.grey
        ..style = PaintingStyle.fill;

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        true,
        paint,
      );

      startAngle += sweepAngle;
    }

    // Draw center circle for donut effect (optional)
    final whitePaint = Paint()..color = Colors.white;
    canvas.drawCircle(center, radius * 0.4, whitePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// Custom Painter for Student Participation Pie Chart
class StudentPieChartPainter extends CustomPainter {
  final int active;
  final int inactive;

  StudentPieChartPainter({required this.active, required this.inactive});

  @override
  void paint(Canvas canvas, Size size) {
    final total = active + inactive;
    if (total == 0) return;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    double startAngle = -90 * (3.14159 / 180);

    // Draw active slice
    if (active > 0) {
      final activeAngle = (active / total) * 360 * (3.14159 / 180);
      final activePaint = Paint()
        ..color = Colors.green
        ..style = PaintingStyle.fill;

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        activeAngle,
        true,
        activePaint,
      );

      startAngle += activeAngle;
    }

    // Draw inactive slice
    if (inactive > 0) {
      final inactiveAngle = (inactive / total) * 360 * (3.14159 / 180);
      final inactivePaint = Paint()
        ..color = Colors.red
        ..style = PaintingStyle.fill;

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        inactiveAngle,
        true,
        inactivePaint,
      );
    }

    // Draw center circle for donut effect
    final whitePaint = Paint()..color = Colors.white;
    canvas.drawCircle(center, radius * 0.5, whitePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}