import 'package:flutter/material.dart';
import '../models/app_user.dart';
import '../models/event.dart';

class EventsScreen extends StatefulWidget {
  final AppUser user;
  final List<Event> events;
  final VoidCallback? onEventStatusChange;

  const EventsScreen({super.key, required this.user, required this.events, this.onEventStatusChange});

  @override
  State<EventsScreen> createState() => _EventsScreenState();
}

class _EventsScreenState extends State<EventsScreen> with SingleTickerProviderStateMixin {
  String _searchQuery = '';
  late TabController _tabController;
  int _selectedCategoryIndex = 0;

  final List<String> _categories = ['All', 'Academic', 'Career', 'Industrial', 'Social', 'Cultural', 'Sports'];

  List<Event> get _filteredEvents {
    var filtered = widget.events.where((event) {
      return event.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          event.description.toLowerCase().contains(_searchQuery.toLowerCase());
    }).toList();

    if (_selectedCategoryIndex > 0) {
      final selectedCategory = _categories[_selectedCategoryIndex];
      filtered = filtered.where((event) => event.category == selectedCategory).toList();
    }

    return filtered;
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _categories.length, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        setState(() {
          _selectedCategoryIndex = _tabController.index;
        });
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;

    return Container(
      color: Colors.grey.shade50,
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, 24, isMobile ? 16 : 24, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Available Events',
                  style: TextStyle(
                    fontSize: isMobile ? 24 : 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Browse and register for upcoming events',
                  style: TextStyle(
                    fontSize: isMobile ? 14 : 16,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),

          Padding(
            padding: EdgeInsets.symmetric(horizontal: isMobile ? 16 : 24),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search events...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                filled: true,
                fillColor: Colors.white,
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
            ),
          ),

          Container(
            margin: const EdgeInsets.symmetric(vertical: 16),
            height: 45,
            child: TabBar(
              controller: _tabController,
              isScrollable: true,
              labelColor: Colors.blue.shade800,
              unselectedLabelColor: Colors.grey,
              indicatorColor: Colors.blue.shade800,
              tabs: _categories.map((category) {
                return Tab(
                  child: Text(
                    category,
                    style: TextStyle(
                      fontSize: isMobile ? 12 : 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              }).toList(),
            ),
          ),

          Padding(
            padding: EdgeInsets.symmetric(horizontal: isMobile ? 16 : 24),
            child: Row(
              children: [
                Text(
                  '${_filteredEvents.length} events found',
                  style: TextStyle(
                    fontSize: isMobile ? 12 : 14,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),

          Expanded(
            child: Padding(
              padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, 8, isMobile ? 16 : 24, 24),
              child: _filteredEvents.isEmpty
                  ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.event_busy,
                      size: isMobile ? 40 : 48,
                      color: Colors.grey.shade400,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'No events found',
                      style: TextStyle(
                        fontSize: isMobile ? 14 : 16,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              )
                  : ListView.builder(
                itemCount: _filteredEvents.length,
                itemBuilder: (context, index) {
                  final event = _filteredEvents[index];
                  final isRegistered = event.isStudentRegistered(widget.user.id);

                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(isMobile ? 12 : 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            event.title,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: isMobile ? 16 : 18,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(Icons.access_time, size: isMobile ? 16 : 18, color: Colors.grey.shade600),
                              const SizedBox(width: 8),
                              Text(
                                event.time,
                                style: TextStyle(fontSize: isMobile ? 13 : 14),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(Icons.location_on, size: isMobile ? 16 : 18, color: Colors.grey.shade600),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  event.location,
                                  style: TextStyle(fontSize: isMobile ? 13 : 14),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(Icons.person, size: isMobile ? 16 : 18, color: Colors.grey.shade600),
                              const SizedBox(width: 8),
                              Text(
                                event.organizer,
                                style: TextStyle(fontSize: isMobile ? 13 : 14),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            event.description,
                            style: TextStyle(
                              fontSize: isMobile ? 13 : 14,
                              color: Colors.grey.shade700,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: event.isAvailable ? Colors.green.shade50 : Colors.red.shade50,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  '${event.registeredCount}/${event.maxAttendees} spots',
                                  style: TextStyle(
                                    color: event.isAvailable ? Colors.green : Colors.red,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              if (!isRegistered)
                                ElevatedButton(
                                  onPressed: event.isAvailable ? () => _registerForEvent(event) : null,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.blue.shade300,
                                    foregroundColor: Colors.white,
                                  ),
                                  child: const Text('Register'),
                                )
                              else
                                Chip(
                                  label: const Text('Registered'),
                                  backgroundColor: Colors.green.shade100,
                                  labelStyle: TextStyle(
                                    color: Colors.green.shade800,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _registerForEvent(Event event) {
    setState(() {
      event.registeredStudents.add(widget.user.id);
    });
    if (widget.onEventStatusChange != null) {
      widget.onEventStatusChange!();
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Registered for ${event.title}!'),
        backgroundColor: Colors.green,
      ),
    );
  }
}