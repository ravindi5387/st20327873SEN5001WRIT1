class AppUser {
  final String id;
  final String name;
  final String email;
  final String password;
  final String role;
  final String? studentId;
  final String? department;
  final int? year;

  AppUser({
    required this.id,
    required this.name,
    required this.email,
    required this.password,
    required this.role,
    this.studentId,
    this.department,
    this.year,
  });
}

// Mock users for demo
final List<AppUser> mockUsers = [
  AppUser(
    id: '1',
    name: 'Admin User',
    email: 'admin@university.edu',
    password: 'admin123',
    role: 'admin',
  ),
  AppUser(
    id: '2',
    name: 'John Student',
    email: 'john@student.edu',
    password: 'student123',
    role: 'student',
    studentId: 'STU001',
    department: 'Computer Science',
    year: 3,
  ),
  AppUser(
    id: '3',
    name: 'Sarah Student',
    email: 'sarah@student.edu',
    password: 'student123',
    role: 'student',
    studentId: 'STU002',
    department: 'Engineering',
    year: 2,
  ),
];

// This will store registered users from the registration form
List<AppUser> registeredUsers = [];