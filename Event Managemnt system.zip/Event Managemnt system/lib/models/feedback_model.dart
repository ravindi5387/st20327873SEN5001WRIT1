class FeedbackModel {
  final String id;
  final String eventId;
  final String studentId;
  final String studentName;
  final String comment;
  final DateTime timestamp;
  int starRating;

  FeedbackModel({
    required this.id,
    required this.eventId,
    required this.studentId,
    required this.studentName,
    required this.comment,
    required this.timestamp,
    required this.starRating,
  });
}

// Mock feedback for demo
final List<FeedbackModel> mockFeedbacks = [
  FeedbackModel(
    id: '1',
    eventId: '1',
    studentId: '2',
    studentName: 'John Student',
    comment: 'Great event! Learned a lot about new technologies.',
    timestamp: DateTime.now().subtract(const Duration(days: 2)),
    starRating: 5,
  ),
  FeedbackModel(
    id: '2',
    eventId: '1',
    studentId: '3',
    studentName: 'Sarah Student',
    comment: 'Well organized, but could use more networking time.',
    timestamp: DateTime.now().subtract(const Duration(days: 2)),
    starRating: 4,
  ),
];