class Event {
  final String id;
  final String title;
  final String description;
  final DateTime date;
  final String time;
  final String location;
  final String organizer;
  final int maxAttendees;
  List<String> registeredStudents;
  List<String> notAttendingStudents;
  Map<String, int> starRatings;
  bool isPublished;
  final String category;

  Event({
    required this.id,
    required this.title,
    required this.description,
    required this.date,
    required this.time,
    required this.location,
    required this.organizer,
    required this.maxAttendees,
    this.registeredStudents = const [],
    this.notAttendingStudents = const [],
    this.starRatings = const {},
    this.isPublished = false,
    required this.category,
  });

  double get averageRating {
    if (starRatings.isEmpty) return 0;
    return starRatings.values.reduce((a, b) => a + b) / starRatings.length;
  }

  int get registeredCount => registeredStudents.length;
  int get notAttendingCount => notAttendingStudents.length;
  bool get isAvailable => registeredCount < maxAttendees;

  bool isStudentRegistered(String studentId) => registeredStudents.contains(studentId);
  bool isStudentNotAttending(String studentId) => notAttendingStudents.contains(studentId);
}

// Mock events for demo
final List<Event> mockEvents = [
  Event(
    id: '1',
    title: 'Tech Symposium 2024',
    description: 'Annual technology symposium featuring guest speakers from top tech companies. Learn about AI, Machine Learning, and Cloud Computing.',
    date: DateTime.now().add(const Duration(days: 7)),
    time: '10:00 AM - 4:00 PM',
    location: 'Engineering Building, Room 101',
    organizer: 'CS Department',
    maxAttendees: 100,
    registeredStudents: ['2'],
    notAttendingStudents: [],
    category: 'Academic',
    isPublished: true,
  ),
  Event(
    id: '2',
    title: 'Career Fair 2024',
    description: 'Meet with recruiters from top companies including Google, Microsoft, Amazon, and local startups.',
    date: DateTime.now().add(const Duration(days: 14)),
    time: '9:00 AM - 5:00 PM',
    location: 'Student Union Building',
    organizer: 'Career Services',
    maxAttendees: 200,
    registeredStudents: ['2', '3'],
    notAttendingStudents: [],
    category: 'Career',
    isPublished: true,
  ),
  Event(
    id: '3',
    title: 'Welcome Party',
    description: 'Kick off the semester with music, food, and games.',
    date: DateTime.now().add(const Duration(days: 3)),
    time: '7:00 PM - 11:00 PM',
    location: 'Campus Quad',
    organizer: 'Student Affairs',
    maxAttendees: 150,
    registeredStudents: [],
    notAttendingStudents: [],
    category: 'Social',
    isPublished: true,
  ),
];