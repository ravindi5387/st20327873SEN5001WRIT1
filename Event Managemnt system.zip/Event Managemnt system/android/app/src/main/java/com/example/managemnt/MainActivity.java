package com.example.managemnt;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
